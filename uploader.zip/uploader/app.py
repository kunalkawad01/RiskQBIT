from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from numpy.random import default_rng
from scipy import stats
from scipy.stats import norm
from flask_cors import CORS
import io

app = Flask(__name__)
CORS(app)  

# Global variable to store the uploaded file data
uploaded_file_data = None

def generate_simulations(factor, data):
    rg = default_rng()
    stat_matrix = data.describe()
    data_simulation = np.around(rg.normal(stat_matrix[factor]["mean"], stat_matrix[factor]["std"], 10000))
    data_simulation[data_simulation < 0] = stat_matrix[factor]["mean"]  # Handle negative values
    return data_simulation

@app.route('/upload', methods=['POST'])
def upload_file():
    global uploaded_file_data
      
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    try:
        # Read the file into a pandas DataFrame and store its content
        uploaded_file_data = file.read()
        # You might want to save this file or process it as needed
        return jsonify({'message': 'File uploaded successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/run-simulation', methods=['POST'])
def run_simulation():
    global uploaded_file_data

    if uploaded_file_data is None:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        df = pd.read_csv(io.BytesIO(uploaded_file_data))
        
        # Ensure required columns are present
        if 'Bug' not in df.columns or 'Task' not in df.columns:
            return jsonify({'error': 'Required columns are missing from the file'}), 400
        
        # Run simulations
        bugs_sim = generate_simulations('Bug', df)
        task_sim = generate_simulations('Task', df)
        task_sim[task_sim == 0] = task_sim.mean()
        ratio_bugs_to_task_sim = bugs_sim / task_sim
        ratio_bugs_to_task_sim[ratio_bugs_to_task_sim > 1] = 1
        mean_ratio = ratio_bugs_to_task_sim.mean()
        std_ratio = ratio_bugs_to_task_sim.std()
        
        rv_normal = norm(loc=mean_ratio, scale=std_ratio)
       
        # Return simulation results
        return jsonify({
            'mean_ratio': mean_ratio,
            'bugs_sim': bugs_sim.tolist(),
            'task_sim': task_sim.tolist(),
            'std_ratio': std_ratio,
            'rv_normal': {
                'mean': rv_normal.mean(),
                'std': rv_normal.std()
            },
            "ratio_bugs_to_task_sim": ratio_bugs_to_task_sim.tolist()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get-columns', methods=['GET'])
def get_columns():
    global uploaded_file_data
    if uploaded_file_data is None:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        df = pd.read_csv(io.BytesIO(uploaded_file_data))
        columns = df.columns.tolist()
        return jsonify({"columns": columns})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/remove-outliers', methods=['POST'])
def remove_outliers():
    global uploaded_file_data
    if uploaded_file_data is None:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        column = request.json.get('column')
        method = request.json.get('method')
        threshold = float(request.json.get('threshold', 1.5))  # Default threshold for IQR

        df = pd.read_csv(io.BytesIO(uploaded_file_data))
        
        if column not in df.columns:
            return jsonify({"error": f"Column '{column}' not found in CSV"}), 400

        if method == "z-score":
            z_scores = np.abs(stats.zscore(df[column]))
            filtered_entries = (z_scores < threshold)
            cleaned_data = df[filtered_entries]
        elif method == "iqr":
            Q1 = df[column].quantile(0.25)
            Q3 = df[column].quantile(0.75)
            IQR = Q3 - Q1
            filtered_entries = ~((df[column] < (Q1 - threshold * IQR)) | (df[column] > (Q3 + threshold * IQR)))
            cleaned_data = df[filtered_entries]
        else:
            return jsonify({"error": "Invalid method"}), 400
        
        return jsonify({"cleaned_data": cleaned_data.to_dict(orient="records")})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
