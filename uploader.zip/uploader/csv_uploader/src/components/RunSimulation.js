import React from "react";
import axios from "axios";

const RunSimulation = ({ setResult }) => {
  const onRunSimulation = async () => {
    try {
      const response = await axios.post("http://localhost:5000/run-simulation");
      setResult(response.data);
    } catch (error) {
      console.error("Error running simulation:", error);
    }
  };

  return (
    <div>
      <button onClick={onRunSimulation} className="btn btn-primary">
        Run Simulation
      </button>
    </div>
  );
};

export default RunSimulation;
