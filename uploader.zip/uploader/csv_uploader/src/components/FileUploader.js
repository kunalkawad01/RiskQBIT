import React, { useState } from "react";
import axios from "axios";

const FileUploader = ({ setFileContent }) => {
  const [file, setFile] = useState(null);

  const onFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const onUpload = async () => {
    if (!file) {
      alert("Please select a file first.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      await axios.post("http://localhost:5000/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      // Optionally, you can fetch columns or reset file content here
      setFileContent(null); // Reset file content if needed
      alert("File uploaded successfully.");
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  return (
    <div>
      <input type="file" onChange={onFileChange} />
      <button onClick={onUpload} className="btn btn-primary">
        Upload
      </button>
    </div>
  );
};

export default FileUploader;
