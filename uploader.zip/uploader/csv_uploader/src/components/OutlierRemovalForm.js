import React, { useState, useEffect } from "react";
import axios from "axios";
import { Form, Button, Spinner, Alert, Table, Navbar } from "react-bootstrap";
import Histogram from "./Histogram";
import Navbarc from "./Navbarc";

const OutlierRemovalForm = () => {
  const [columns, setColumns] = useState([]);
  const [selectedColumn, setSelectedColumn] = useState("");
  const [method, setMethod] = useState("z-score");
  const [threshold, setThreshold] = useState(3);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [cleanedData, setCleanedData] = useState([]);

  // Fetch columns from the server
  useEffect(() => {
    const fetchColumns = async () => {
      try {
        const response = await axios.get("http://localhost:5000/get-columns");
        setColumns(response.data.columns);
      } catch (error) {
        console.error("Error fetching columns:", error);
        setError("Failed to fetch columns. Please try again.");
      }
    };

    fetchColumns();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post(
        "http://localhost:5000/remove-outliers",
        {
          column: selectedColumn,
          method,
          threshold,
        }
      );
      setCleanedData(response.data.cleaned_data); // Update state with cleaned data
    } catch (error) {
      console.error("Error removing outliers:", error);
      setError("Failed to remove outliers. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbarc></Navbarc>

      <div className="container mt-4">
        <div className="p-4 bg-dark text-light rounded border border-secondary">
          <h3 className="mb-4 text-primary">Remove Outliers</h3>
          <Form onSubmit={handleSubmit} className="text-light">
            <Form.Group controlId="column" className="mb-3">
              <Form.Label>Select Column</Form.Label>
              <Form.Control
                as="select"
                value={selectedColumn}
                onChange={(e) => setSelectedColumn(e.target.value)}
                disabled={!columns.length}
                className="bg-secondary text-light border-light"
              >
                <option value="" disabled>
                  Select a column
                </option>
                {columns.map((col, index) => (
                  <option key={index} value={col}>
                    {col}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
            <Form.Group controlId="method" className="mb-3">
              <Form.Label>Outlier Removal Method</Form.Label>
              <Form.Control
                as="select"
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="bg-secondary text-light border-light"
              >
                <option value="z-score">Z-Score</option>
                <option value="iqr">IQR</option>
              </Form.Control>
            </Form.Group>
            <Form.Group controlId="threshold" className="mb-3">
              <Form.Label>Threshold Value</Form.Label>
              <Form.Control
                type="number"
                value={threshold}
                onChange={(e) => setThreshold(e.target.value)}
                placeholder="Enter threshold value"
                className="bg-secondary text-light border-light"
              />
            </Form.Group>
            <Button
              variant="primary"
              type="submit"
              disabled={loading}
              className="w-100"
            >
              {loading ? (
                <>
                  <Spinner
                    as="span"
                    animation="border"
                    size="sm"
                    role="status"
                    aria-hidden="true"
                  />
                  <span className="visually-hidden">Processing...</span>
                </>
              ) : (
                "Submit"
              )}
            </Button>
            {loading && (
              <div className="loader-overlay mt-3">
                <Spinner animation="border" variant="primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </Spinner>
              </div>
            )}
            {error && (
              <Alert variant="danger" className="mt-3">
                {error}
              </Alert>
            )}
          </Form>
          {cleanedData.length > 0 && (
            <div className="mt-4">
              <h4 className="mb-3 text-primary">Cleaned Data</h4>
              <Table striped bordered hover variant="dark">
                <thead>
                  <tr>
                    {Object.keys(cleanedData[0]).map((key) => (
                      <th key={key}>{key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cleanedData.map((row, index) => (
                    <tr key={index}>
                      {Object.values(row).map((value, idx) => (
                        <td key={idx}>{value}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </Table>
              {selectedColumn && (
                <div className="mt-4">
                  <Histogram
                    data={cleanedData.map((item) => item[selectedColumn])}
                    title="Distribution of Selected Column"
                    xLabel={selectedColumn}
                    yLabel="Frequency"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default OutlierRemovalForm;
