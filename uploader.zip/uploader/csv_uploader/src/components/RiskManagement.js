import React from "react";

const RiskManagement = () => (
  <section className="bg-dark text-light p-5 p-lg-0 pt-lg-5 text-center text-sm-start">
    <div className="container">
      <div className="d-sm-flex align-items-center justify-content-between">
        <div>
          <h1>
            Become a Stalwart
            <span className="text-warning"> Risk Manager </span>
          </h1>
          <p className="lead my-4">
            Achieve resilience and stability with our risk management services.
          </p>
          <button
            className="btn btn-primary btn-lg mb-5"
            data-bs-toggle="modal"
            data-bs-target="#enroll"
          >
            Explore our risk management model
          </button>
        </div>
        <img
          className="img-fluid w-50 d-none d-sm-block"
          src="risk-img.svg"
          alt=""
        />
      </div>
    </div>
  </section>
);

export default RiskManagement;
