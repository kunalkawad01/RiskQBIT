import React from "react";

const Cards = (props) => {
  return (
    <section class="p-5">
      <div class="container">
        <div class="row text-center g-4">
          <div class="col-md">
            <div class="card bg-dark text-light">
              <div class="card-body text-center">
                <div class="h1 mb-3">
                  <i class="bi bi-laptop"></i>
                </div>
                <h3 class="card-title mb-3">Outlier Analysis</h3>
                <p class="card-text">
                  Focuses on identifying data points that significantly deviate
                  from the rest of the dataset
                </p>
                <a href="#" class="btn btn-primary">
                  Read More
                </a>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="card bg-secondary text-light">
              <div class="card-body text-center">
                <div class="h1 mb-2">
                  <i class="bi bi-person-square"></i>
                </div>
                <h3 class="card-title mb-3">ML Algorithm</h3>
                <p class="card-text">
                  Learn from data to make predictions or decisions without
                  explicit programming..
                </p>
                <a href="#" class="btn btn-dark m-1">
                  Read More
                </a>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="card bg-dark text-light">
              <div class="card-body text-center">
                <div class="h1 mb-3">
                  <i class="bi bi-people"></i>
                </div>
                <h3 class="card-title mb-3">Data Visualization</h3>
                <p class="card-text">
                  Transform complex datasets into insightful visual
                  representations
                </p>
                <a href="#" class="btn btn-primary">
                  Read More
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Cards;
