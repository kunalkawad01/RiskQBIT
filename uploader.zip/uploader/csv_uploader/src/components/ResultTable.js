import React from "react";
import Histogram from "./Histogram";

const ResultTable = ({ result }) => {
  if (!result) {
    return <p>No results to display</p>;
  }

  return (
    <div>
      <h3>Simulation Results</h3>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Mean Ratio (Actual)</th>
            <th>Std Ratio (Actual)</th>
            <th>RV Normal Mean</th>
            <th>RV Normal Std</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{result.mean_ratio.toFixed(3)}</td>
            <td>{result.std_ratio.toFixed(3)}</td>
            <td>{result.rv_normal.mean.toFixed(3)}</td>
            <td>{result.rv_normal.std.toFixed(3)}</td>
          </tr>
        </tbody>
      </table>

      <div
        style={{ display: "flex", justifyContent: "space-around", gap: "1rem" }}
      >
        <div style={{ flex: 1 }}>
          <Histogram
            data={result.bugs_sim}
            title="Bugs"
            xLabel="Bugs"
            yLabel="Frequency"
          />
        </div>
        <div style={{ flex: 1 }}>
          <Histogram
            data={result.task_sim}
            title="Tasks"
            xLabel="Tasks"
            yLabel="Frequency"
          />
        </div>
        <div style={{ flex: 2 }}>
          <Histogram
            data={result.ratio_bugs_to_task_sim}
            title="Bugs to Task Ratio"
            xLabel="Ratio"
            yLabel="Frequency"
          />
        </div>
      </div>
    </div>
  );
};

export default ResultTable;
