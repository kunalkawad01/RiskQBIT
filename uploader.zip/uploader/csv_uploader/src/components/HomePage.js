import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import FileUploader from "./FileUploader";
import ResultTable from "./ResultTable";
import RiskManagement from "./RiskManagement";
import Cards from "./Cards";
import RunSimulation from "./RunSimulation";

const HomePage = () => {
  const [fileContent, setFileContent] = useState(null);
  const [result, setResult] = useState(null);

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            Risk Management
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link active" aria-current="page" href="#">
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">
                  Features
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">
                  Monte Carlo
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <RiskManagement />
      <Cards />
      <div className="container">
        <header className="my-1">
          <h2 className="text font-weight-bold" style={{ color: "#02b3e4" }}>
            CSV Uploader
          </h2>
          <FileUploader setFileContent={setFileContent} />
          <RunSimulation setResult={setResult} />
          <ResultTable result={result} />
        </header>
      </div>

      <footer className="p-5 bg-dark text-white text-center position-relative">
        <div className="container">
          <p className="lead">QBIT 2024 Data Strategy</p>

          <a href="#" className="position-absolute bottom-0 end-0 p-5">
            <i className="bi bi-arrow-up-circle h1"></i>
          </a>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
