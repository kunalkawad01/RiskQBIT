import React from "react";
import Plot from "react-plotly.js";

const Histogram = ({ data, xLabel = "Value", title }) => {
  return (
    <Plot
      data={[
        {
          type: "histogram",
          x: data,
        },
      ]}
      layout={{
        title: title,
        xaxis: { title: xLabel },
        yaxis: { title: "Count" },
      }}
    />
  );
};

export default Histogram;
