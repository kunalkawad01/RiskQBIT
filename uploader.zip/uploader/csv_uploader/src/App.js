import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import HomePage from "./components/HomePage"; // Example Home component
import OutlierRemovalForm from "./components/OutlierRemovalForm";
// Example 404 component

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/outlier-removal" element={<OutlierRemovalForm />} />
      </Routes>
    </Router>
  );
};

export default App;
